<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>configDialogBase</name>
    <message>
        <location filename="config_dialog_base.py" line="153"/>
        <source>Enviar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="154"/>
        <source>Eliminar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="155"/>
        <source>Registo de Comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="156"/>
        <source>Pasta de registo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="157"/>
        <source>Registar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="158"/>
        <source>Registar respostas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="159"/>
        <source>Emitir um CLEAR antes de enviar mapa</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="config_dialog_base.py" line="160"/>
        <source>Usar transparências</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="config_dialog_base.py" line="161"/>
        <source>Display multimédia host e ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="config_dialog_base.py" line="162"/>
        <source>Escala dos símbolos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="163"/>
        <source>Controlador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="164"/>
        <source>Mapeamento de pastas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="165"/>
        <source>Adicionar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>gison3dmap</name>
    <message>
        <location filename="gison3dmap.py" line="210"/>
        <source>&amp;gison3dmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="176"/>
        <source>Sele&#xc3;&#xa7;&#xc3;&#xa3;o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="181"/>
        <source>Camada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="186"/>
        <source>Mapa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="191"/>
        <source>Limpar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="196"/>
        <source>Enviar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="201"/>
        <source>Configura&#xc3;&#xa7;&#xc3;&#xa3;o</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>gison3dmapDialogBase</name>
    <message>
        <location filename="gison3dmap_dialog_base.py" line="69"/>
        <source>Enviar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap_dialog_base.py" line="70"/>
        <source>Comando</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap_dialog_base.py" line="71"/>
        <source>Sintaxe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
