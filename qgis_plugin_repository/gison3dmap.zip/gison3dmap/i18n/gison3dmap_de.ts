<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>configDialogBase</name>
    <message>
        <location filename="config_dialog_base.py" line="160"/>
        <source>Enviar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="161"/>
        <source>Eliminar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="162"/>
        <source>Registo de Comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="165"/>
        <source>Pasta de registo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="163"/>
        <source>Registar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="164"/>
        <source>Registar respostas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="167"/>
        <source>Emitir um CLEAR antes de enviar mapa</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="config_dialog_base.py" line="168"/>
        <source>Usar transparências</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="config_dialog_base.py" line="169"/>
        <source>Display multimédia host e ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="config_dialog_base.py" line="170"/>
        <source>Escala dos símbolos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="171"/>
        <source>Controlador</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="172"/>
        <source>Mapeamento de pastas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="173"/>
        <source>Adicionar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="config_dialog_base.py" line="166"/>
        <source>Procurar...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>gison3dmap</name>
    <message>
        <location filename="gison3dmap.py" line="216"/>
        <source>&amp;gison3dmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="174"/>
        <source>Sele&#xc3;&#xa7;&#xc3;&#xa3;o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="186"/>
        <source>Mapa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="192"/>
        <source>Limpar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="197"/>
        <source>Enviar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="202"/>
        <source>Configura&#xc3;&#xa7;&#xc3;&#xa3;o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap.py" line="180"/>
        <source>Camada ou Grupo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>gison3dmapDialogBase</name>
    <message>
        <location filename="gison3dmap_dialog_base.py" line="69"/>
        <source>Enviar comandos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap_dialog_base.py" line="70"/>
        <source>Comando</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gison3dmap_dialog_base.py" line="71"/>
        <source>Sintaxe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
