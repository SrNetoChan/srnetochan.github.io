# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'gison3dmap_dialog_base.ui'
#
# Created: Sun Oct 25 23:27:17 2015
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_gison3dmapDialogBase(object):
    def setupUi(self, gison3dmapDialogBase):
        gison3dmapDialogBase.setObjectName(_fromUtf8("gison3dmapDialogBase"))
        gison3dmapDialogBase.resize(400, 200)
        gison3dmapDialogBase.setMinimumSize(QtCore.QSize(400, 200))
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("../../../../../../../../home/alexandre/Dropbox/Trabalho/QGIS/Plugins-QGIS/gison3dmap/icons/cmdComando.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        gison3dmapDialogBase.setWindowIcon(icon)
        self.gridLayout = QtGui.QGridLayout(gison3dmapDialogBase)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.button_box = QtGui.QDialogButtonBox(gison3dmapDialogBase)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName(_fromUtf8("button_box"))
        self.gridLayout.addWidget(self.button_box, 3, 0, 1, 2)
        self.label_2 = QtGui.QLabel(gison3dmapDialogBase)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.textBrowser = QtGui.QTextBrowser(gison3dmapDialogBase)
        self.textBrowser.setAutoFillBackground(False)
        self.textBrowser.setStyleSheet(_fromUtf8(""))
        self.textBrowser.setFrameShape(QtGui.QFrame.StyledPanel)
        self.textBrowser.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.textBrowser.setObjectName(_fromUtf8("textBrowser"))
        self.gridLayout.addWidget(self.textBrowser, 1, 1, 1, 1)
        self.comboBox = QtGui.QComboBox(gison3dmapDialogBase)
        self.comboBox.setEditable(True)
        self.comboBox.setMaxVisibleItems(20)
        self.comboBox.setInsertPolicy(QtGui.QComboBox.InsertAlphabetically)
        self.comboBox.setFrame(True)
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.gridLayout.addWidget(self.comboBox, 0, 1, 1, 1)
        self.label_3 = QtGui.QLabel(gison3dmapDialogBase)
        self.label_3.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)

        self.retranslateUi(gison3dmapDialogBase)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("accepted()")), gison3dmapDialogBase.accept)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("rejected()")), gison3dmapDialogBase.reject)
        QtCore.QMetaObject.connectSlotsByName(gison3dmapDialogBase)

    def retranslateUi(self, gison3dmapDialogBase):
        gison3dmapDialogBase.setWindowTitle(_translate("gison3dmapDialogBase", "Enviar comandos", None))
        self.label_2.setText(_translate("gison3dmapDialogBase", "Comando", None))
        self.label_3.setText(_translate("gison3dmapDialogBase", "Sintaxe", None))

